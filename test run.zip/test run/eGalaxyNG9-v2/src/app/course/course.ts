export class Course
{
  courseId: number;
  courseName: string;
  courseAuthor: string;
  courseDescription: string;
  coursePrice: number;
}