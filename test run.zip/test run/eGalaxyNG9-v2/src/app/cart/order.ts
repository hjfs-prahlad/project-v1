export class Order {
    orderId: number;
    courseId: number;
    courseName: string;
    courseDescription: string;
}