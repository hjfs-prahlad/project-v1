export class User {
    userId: number;
    userName: string;
    userEmail: string;
    userPassword: string;
    userDob: string;
    userGender: string;
}