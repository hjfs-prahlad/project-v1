export class Cart {
    cartId: number;
    courseId: number;
    courseName: string;
    courseDescription: string;
}