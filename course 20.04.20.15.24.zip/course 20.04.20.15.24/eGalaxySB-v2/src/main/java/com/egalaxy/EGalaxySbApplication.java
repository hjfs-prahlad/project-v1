package com.egalaxy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EGalaxySbApplication {
	public static void main(String[] args) {
		SpringApplication.run(EGalaxySbApplication.class, args);
		System.out.print("Hello there!");
	}
}
